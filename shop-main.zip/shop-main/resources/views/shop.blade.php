@extends('layouts.app')

@section('content')
<x-product-list></x-product-list>
@endsection
